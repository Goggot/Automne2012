
import random

class Jeu():
    def __init__(self, score):
        self.score=score


class Docteur():
    def __init__(self):
        x=0
        y=0
        self.pos=[x,y]
        
    def DeplacementDoc(self,calcDep):
        self.x = Docteur.x
        self.y = Docteur.y
        calcDep={"8" : [self.y+1],
                 "2" : [self.y-1],
                 "4" : [self.x-1],
                 "6" : [self.x+1],
                 "7" : [self.x-1,self.y+1],
                 "9" : [self.x+1,self.y+1],
                 "1" : [self.x-1,self.y-1],
                 "3" : [self.x+1,self.y-1],
                 "z" : DocTire(),
                 "t" : DocTeleporte()}
        
    def DocTire(self):
        AireDeJeu.dalek[x,y+1].remove
        AireDeJeu.dalek[x,y-1].remove
        AireDeJeu.dalek[x-1,y].remove
        AireDeJeu.dalek[x+1,y].remove
        AireDeJeu.dalek[x-1,y+1].remove
        AireDeJeu.dalek[x+1,y+1].remove
        AireDeJeu.dalek[x-1,y-1].remove
        AireDeJeu.dalek[x+1,y-1].remove

    def DocTeleporte(self):
        self.x = Docteur.x
        self.y = Docteur.y
        input(x)
        input(y)

class Dalek():
    def __init__(self, parent, pos):
        self.pos=[0,0]
        self.parent=parent
        self.nbrDalek=self.parent

    def Collision(self):
        for i in AireDeJeu.dalek.length:
            for j in AireDeJeu.dalek.length:
                if i!=j:
                    if AireDeJeu.dalek[i] == AireDeJeu.dalek[j]:
                        Ferraille(AireDeJeu.dalek[i][0], AireDeJeu.dalek[i][1])
                        AireDeJeu.dalek[i].remove
                        AireDeJeu.dalek[j].remove
                        self.nbrDalek = self.nbrDalek-2
                        AireDeJeu.pointage = AireDeJeu.pointage+10
                        
                    
class Ferraille():
    def __init__(self,x,y):
        AireDeJeu.ferraille[AireDeJeu.ferraille.length+1][0]= x
        AireDeJeu.ferraille[AireDeJeu.ferraille.length+1][1]= y


class AireDeJeu():
    def __init__(self):
        self.doc = Docteur()
        self.largeur = 20   #tableau x
        self.hauteur = 20   #tableau y
        self.nbDalekParNiveau = 5
        self.nbDalek = 0
        self.dalek=[]
        self.pointage=0
        self.ferraille=[]
        self.niveau = 0
        self.initNiveau()
        
    def initNiveau(self):
        self.niveau = self.niveau+1 #prochain niveau
        xdoc = random.randrange(self.largeur)   #trouve une position x
        ydoc = random.randrange(self.hauteur)   #trouve une position y
        self.doc.pos=[xdoc, ydoc]

        listePos=[[xdoc,ydoc]] 
        self.nbDalek = self.nbDalekParNiveau*self.niveau
        for i in range(self.nbDalek):  #for : prochain element de la sequence
           x = random.randrange(self.largeur)   #trouve une position x
           y = random.randrange(self.hauteur)   #trouve une position y
           if[x,y] in listePos:
              i = i-1
           else:
              listePos.append([x,y])    #creer un nouveau dalek
        listePos.remove([xdoc,ydoc])
        for i in listePos:
            self.dalek.append(Dalek(self,i))

       
class Controleur():
    def __init__(self):
        self.modele = AireDeJeu()
        self.vue= Vue(self.modele)
        self.vue.AvertirChoixMenu(self.modele)
        
    
    def dictionnaire(self,reponse):
        calcDep=reponse
        Docteur.DeplacementDoc(self, calcDep)


class Vue():
    def __init__(self, modele):
        self.hauteur = modele.hauteur
        self.largeur = modele.largeur
            
    def afficherAireDeJeu(self, modele):
        self.grille=[]
        for i in range(self.hauteur):
            r=[]
            for j in range(self.largeur):
                r.append(' ')
            self.grille.append(r)
        
        doc=modele.doc
        print("Position du doc : ",doc.pos)
        self.grille[doc.pos[0]][doc.pos[1]]='W'
        
        for x in self.grille:
            print(self.grille)
            
    def AvertirChoixJeu(self):
        reponse=0
        input(reponse)
        Controleur.dictionnaire(self, reponse)
        
    def AvertirChoixMenu(self, modele):
        val = input("1- Jouer\n\t2- Scores\n\t\t3- Quitter\nVotre choix : ")
    
        if val[:-1] == "1":
            self.afficherAireDeJeu(modele)
            self.AvertirChoixJeu()
        elif val[:-1]== "2":
            print("Scores")
        elif val[:-1]== "3":
            print ("Bye")

if __name__ == '__main__': 
    cont = Controleur()
    